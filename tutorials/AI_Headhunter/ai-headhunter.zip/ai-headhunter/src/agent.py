
"""LangGraph head‑hunter graph"""
from typing import Annotated, List
from langchain_core.messages import HumanMessage, AIMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, MessagesState
from langchain_community.tools.tavily_search import TavilySearchResults

from .models import Candidate

llm = ChatOpenAI(model="gpt-4o", temperature=0.2)
tavily = TavilySearchResults(max_results=15, include_domains=["linkedin.com"])

def find_candidates(keyword: str) -> List[Candidate]:
    results = tavily.run(keyword)
    out: List[Candidate] = []
    for hit in results:
        name_and_job = hit.title.split(" - ")
        name = name_and_job[0]
        title = " / ".join(name_and_job[1:]) if len(name_and_job) > 1 else ""
        out.append(
            Candidate(
                name=name,
                title=title,
                company="",
                location="",
                linkedin=hit.url,
                reason=f"Matched '{keyword}'",
            )
        )
    return out

# ---------- LangGraph ----------
State = Annotated[List[HumanMessage | AIMessage], MessagesState]

def chat_node(state: State) -> State:
    user_msg = state[-1]
    rsp = llm.invoke([user_msg])
    return state + [rsp]

def search_node(state: State) -> State:
    query = state[-1].content
    cands = find_candidates(query)
    rsp = AIMessage(content="\n".join(str(c) for c in cands))
    return state + [rsp]

graph = StateGraph()
graph.add_node("chat", chat_node)
graph.add_node("search", search_node)
graph.set_start("chat")
graph.add_edge("chat", "search", condition=lambda s: "search" in s[-1].content.lower())
graph.add_edge("search", "chat")
