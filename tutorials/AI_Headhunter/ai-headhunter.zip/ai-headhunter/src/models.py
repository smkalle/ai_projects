
from dataclasses import dataclass

@dataclass
class Candidate:
    name: str
    title: str
    company: str
    location: str
    linkedin: str
    reason: str
