
from davia import app
from .agent import graph as _graph

@app.graph
def hr():
    return _graph
