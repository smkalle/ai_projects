
# AI‑Headhunter Agent

A minimal reference implementation of a LinkedIn‑sourcing recruiter bot built with **LangGraph** and **Davia**.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # add your real keys
davia dev
```

Open http://localhost:8000 to chat with the agent.

## Project layout

```
ai-headhunter/
├─ .env.example
├─ langgraph.json
├─ requirements.txt
└─ src/
   ├─ models.py
   ├─ agent.py
   └─ __main__.py
```

## What it does
* Parses your prompt (e.g. "search senior ML engineers in Seattle").
* Calls **Tavily** to pull top LinkedIn URLs.
* Streams a structured list of `Candidate` objects back through Davia.
* Uses a LangGraph state machine so you can add extra steps (scoring, messaging, DB‑write) without spaghetti code.

## License
MIT
